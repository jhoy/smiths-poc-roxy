function uploadBox() {
	  $.ajax({
			url: '/upload.xqy',
			data: {				
				action: 'upload'
			},
			dataType: 'html',
			success: function(data) {
				$(data).dialog({
				  title: "Upload Box",
	        width: 625,
	        minWidth: 625,
	        height: 230,
	        minHeight: 230,
	        show: {effect: "fold", duration: 500 },
	        hide: 'clip',
	        close: function(event, ui) {
						$(this).remove();
					}
				});
			}
		});
};